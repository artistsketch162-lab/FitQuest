# FitQuest Android Project

FitQuest is a Jetpack Compose Android app with Home, Learning, Quiz and Progress screens.

## Open in Android Studio
1. Extract this project.
2. Open the project folder in Android Studio.
3. Let Gradle sync/download the required dependencies.
4. Run the `app` configuration on an emulator or Android device.

## Build from terminal
- Linux/macOS: `./gradlew assembleDebug`
- Windows: `gradlew.bat assembleDebug`

Gradle 8.9 is configured for the Android Gradle Plugin 8.7.3.
