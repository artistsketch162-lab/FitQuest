package com.example.fitquest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*

data class Question(val q:String,val options:List<String>,val answer:Int)
data class Lesson(val title:String,val body:String)

@Composable
fun FitQuestApp(){
    val nav=rememberNavController()
    var xp by remember{mutableIntStateOf(30)}
    var coins by remember{mutableIntStateOf(50)}
    val level=(xp/100)+1
    MaterialTheme{
        Scaffold(bottomBar={
            NavigationBar{
                listOf("home" to "🏠","learn" to "📚","quiz" to "🎯","progress" to "🏆").forEach{ (route,icon)->
                    NavigationBarItem(
                        selected=nav.currentDestination?.route==route,
                        onClick={if(nav.currentDestination?.route==route){{} }else{{nav.navigate(route)}}},
                        icon={Text(icon)},label={Text(route.replaceFirstChar{it.uppercase()})})
                }
            }
        }){pad->
            NavHost(nav,"home",Modifier.padding(pad)){
                composable("home"){HomeScreen(level,xp,coins){coins+=10;xp+=20}}
                composable("learn"){LearnScreen()}
                composable("quiz"){QuizScreen{coins+=10;xp+=20}}
                composable("progress"){ProgressScreen(level,xp,coins)}
            }
        }
    }
}

@Composable
fun HomeScreen(level:Int,xp:Int,coins:Int,onChallenge:()->Unit){
    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Text("FitQuest 💪",style=MaterialTheme.typography.headlineLarge)
        Text("Learn • Play • Build Healthy Habits",style=MaterialTheme.typography.bodyLarge)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            AssistChip(onClick={},label={Text("⭐ Level $level")})
            AssistChip(onClick={},label={Text("🪙 $coins")})
        }
        Card(Modifier.fillMaxWidth()){
            Column(Modifier.padding(18.dp)){
                Text("XP Progress",style=MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator({(xp%100)/100f},Modifier.fillMaxWidth())
                Text("$xp XP")
            }
        }
        Card(Modifier.fillMaxWidth()){
            Column(Modifier.padding(18.dp)){
                Text("🎯 Daily Challenge",style=MaterialTheme.typography.titleLarge)
                Text("5-minute light stretching + learn one fitness tip.")
                Spacer(Modifier.height(10.dp))
                Button(onClick=onChallenge){Text("Complete Challenge +20 XP")}
            }
        }
        Text("💡 Fitness tip: Healthy fitness includes regular movement, sleep, hydration and balanced nutrition.")
    }
}

@Composable
fun LearnScreen(){
    val lessons=listOf(
        Lesson("Warm-up","Light warm-up can prepare your body for activity."),
        Lesson("Hydration","Drinking water regularly helps maintain normal hydration."),
        Lesson("Sleep","Good sleep supports learning, recovery and daily energy."),
        Lesson("Daily Movement","Walking, stretching and other comfortable movement can be part of an active day."),
        Lesson("Balanced Nutrition","A variety of nutritious foods helps support normal growth and energy.")
    )
    LazyColumn(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Text("Fitness Learning 📚",style=MaterialTheme.typography.headlineMedium)}
        items(lessons){l->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(l.title,style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(6.dp));Text(l.body)}}}
    }
}

@Composable
fun QuizScreen(onCorrect:()->Unit){
    val questions=listOf(
        Question("Exercise se pehle body ko activity ke liye prepare karne wali practice kya hai?",listOf("Warm-up","Screen time","Skipping sleep","Nothing"),0),
        Question("Daily health ke liye inmein se kaunsi habit useful hai?",listOf("Regular movement","All-day sitting","Skipping sleep","Ignoring hydration"),0),
        Question("Recovery aur learning ke liye kya important hai?",listOf("Good sleep","No rest","Very long workouts","Skipping meals"),0)
    )
    var index by remember{mutableIntStateOf(0)}
    var selected by remember{mutableIntStateOf(-1)}
    var score by remember{mutableIntStateOf(0)}
    val q=questions[index]
    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Fitness Quiz 🎯",style=MaterialTheme.typography.headlineMedium)
        Text("Question ${index+1}/${questions.size}  •  Score $score")
        Text(q.q,style=MaterialTheme.typography.titleLarge)
        q.options.forEachIndexed{i,opt->
            OutlinedButton(onClick={selected=i},Modifier.fillMaxWidth()){Text(opt)}
        }
        if(selected>=0){
            Text(if(selected==q.answer)"✅ Correct!" else "❌ Correct answer: ${q.options[q.answer]}")
            Button(onClick={
                if(selected==q.answer){score++;onCorrect()}
                selected=-1
                index=(index+1)%questions.size
            }){Text("Next")}
        }
    }
}

@Composable
fun ProgressScreen(level:Int,xp:Int,coins:Int){
    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Your Progress 🏆",style=MaterialTheme.typography.headlineMedium)
        Text("Level $level",style=MaterialTheme.typography.titleLarge)
        LinearProgressIndicator({(xp%100)/100f},Modifier.fillMaxWidth())
        Text("⭐ XP: $xp")
        Text("🪙 Coins: $coins")
        Text("🏅 Achievement: First Steps")
        Text("Keep learning and completing safe daily challenges!")
    }
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{FitQuestApp()}}
}
